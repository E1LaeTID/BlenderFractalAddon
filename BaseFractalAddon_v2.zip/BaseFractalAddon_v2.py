bl_info = {
    "name": "3D Fractal Generator",
    "author": "Logmegiga",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "",
    "description": "A simple addon which allow you to spawn a fractal by specifying its length and the level of detail desired",
    "warning": "You must rename the generated object to generate another one or delete it to try again",
    "doc_url": "https://github.com/Z0tman/BlenderFractalAddon/blob/main/README.md",
    "category": "Procedural 3D Geometry",
}

import bpy
import math
from math import *
from mathutils import Vector
import random

from bpy.types import(
    Panel,
    Operator,
    PropertyGroup,
    )
    
from bpy.props import(
    StringProperty,
    PointerProperty,
    FloatProperty,
    IntProperty,
    EnumProperty
    )
    
class FractalPanel(Panel):
    bl_label = "Fractal Panel Setting"
    bl_idname = "OBJECT_PT_fractal"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fractal addon"

    def draw(self, context):
        layout = self.layout
        
        scene = context.scene.fractal_properties
        col = layout.column()
        col.prop(scene,"length")
        col.prop(scene,"maxIteration")
        col = layout.column()
        row = layout.row()
        row.label(text=" type: ")
        col = layout.column()
        row.prop(scene,"basePolygonType")
        row = layout.row()
        col.operator("coupole.generator")
        col = layout.column()
        col.operator("coupole.cleansing")
        col = layout.column()
        col.prop(scene,"fractalName")
        col.operator("coupole.name")


class FractalOperator(Operator):
    bl_idname = "coupole.generator"
    bl_label = "GENERATE"
    bl_description = "spawn a base 3D fractal"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        length = scene.length
        n_max = scene.maxIteration
        polygonType = scene.basePolygonType
        match(polygonType):
            case("SQUARE"):
                spawnFractal(length,n_max)
            case("PENTAGON"):
                if (n_max<5):
                    spawnPentagonFractal(length,n_max)
            case("HEXAGON"):
                if (n_max<5):
                    spawnHexagonFractal(length,n_max)          
            case("HEPTAGON"):
                print("HEPTAGON BASE TYPE SELECTED") 
            case("OCTOGON"):
                spawnOctogonFractal(length,n_max) 

        return {'FINISHED'}
    
class cleansingOperator(Operator):
    bl_idname = "coupole.cleansing"
    bl_label = "CLEAN"
    bl_description = "delete previous iteration objects from the viewport"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        n_max = scene.maxIteration
        polygonType = scene.basePolygonType
        match(polygonType):
            case("SQUARE"):
                cleanSquareFractal(n_max)
            case("PENTAGON"):
                cleanPentagonFractal(n_max)
            case("HEXAGON"):
                cleanHexagonFractal(n_max)          
            case("HEPTAGON"):
                print("HEPTAGON BASE TYPE SELECTED") 
            case("OCTOGON"):
                cleanOctogonFractal(n_max)

        return {'FINISHED'}
    
class renameOperator(Operator):
    bl_idname = "coupole.name"
    bl_label = "RENAME"
    bl_description = "change the name of the generated object after cleansing"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        customName = scene.fractalName
        n_max = scene.maxIteration
        bpy.data.objects["BaseShape-"+str(n_max-1)].name = customName
        return {'FINISHED'}
    
class fractal_Properties(PropertyGroup):
    length : FloatProperty(
        name = "length",
        description = "the size of your fractal",
        default = 10
    )
    
    maxIteration : IntProperty(
        name = "Level Of Details",
        description = "the level of details entailed by the fractal process",
        default = 2
    )
    
    fractalName : StringProperty(
        name="Name",
        description="display name in the collection tab",
        default="BaseShape"
    )

    basePolygonType : EnumProperty(
        name="Polygon Type",
        description="select the polygon type for the base of the fractal you want to generate",
        items= [("SQUARE", "Square", ""),
                ("PENTAGON", "Pentagon", ""),
                ("HEXAGON", "Hexagon", ""),
                ("HEPTAGON", "Heptagon", ""),
                ("OCTOGON", "Octogon", ""),
                ]
        )


classes = (
    FractalPanel,
    FractalOperator,
    cleansingOperator,
    renameOperator,
    fractal_Properties
    )

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fractal_properties = PointerProperty(type=fractal_Properties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.fractal_properties

if __name__ == "__main__":
    register()
#####################################################################################################################################################################
##############################################################____FRACTAL CODE____###################################################################################
#####################################################################################################################################################################    
import bpy
import math
from mathutils import Vector

#####################################################################################################################################################################
###################################################################### SQUARE POLYGON BASE TYPE FRACTAL CODE ########################################################
##################################################################################################################################################################### 
def baseSquareShape(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
       origin + Vector((length/2,length/2,0)),
        origin + Vector((length/2,-length/2,0)),
        origin + Vector((-length/2,-length/2,0)),
        origin + Vector((-length/2,length/2,0)),

        ]
    edges=[]
    faces=[
        (0,1,2,3),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

#initialization
length = 100
angleSquare = math.pi/4

primarySquarePivotPoints = [
    (length/2,0,0),
    (0,-length/2,0),
    (-length/2,0,0),
    (0,length/2,0),
]
    

##cursor3D setting
origin = (0,0,0)

def spawnSquareShapeFractal(length, j):
    #Initialize the geometry shape
    baseSquareShape('CenterMotion-'+str(j), length)
    centerMotion = bpy.context.scene.objects['CenterMotion-'+str(j)]

    baseSquareShape('RightMotion-'+str(j), length)
    rightMotion = bpy.context.scene.objects['RightMotion-'+str(j)]
    rightMotion.rotation_euler.y = angleSquare
    rightMotion.location.x = 0.5*length*(1+math.cos(angleSquare))
    rightMotion.location.z = -0.5*length*math.sin(angleSquare)


    baseSquareShape('LeftMotion-'+str(j), length)
    leftMotion = bpy.context.scene.objects['LeftMotion-'+str(j)]
    leftMotion.rotation_euler.y = -angleSquare
    leftMotion.location.x = -0.5*length*(1+math.cos(angleSquare))
    leftMotion.location.z = -0.5*length*math.sin(angleSquare)

    baseSquareShape('FrontMotion-'+str(j), length)
    frontMotion = bpy.context.scene.objects['FrontMotion-'+str(j)]
    frontMotion.rotation_euler.x = -angleSquare
    frontMotion.location.y = 0.5*length*(1+math.cos(angleSquare))
    frontMotion.location.z = -0.5*length*math.sin(angleSquare)

    baseSquareShape('BackMotion-'+str(j), length)
    backMotion = bpy.context.scene.objects['BackMotion-'+str(j)]
    backMotion.rotation_euler.x = angleSquare
    backMotion.location.y = -0.5*length*(1+math.cos(angleSquare))
    backMotion.location.z = -0.5*length*math.sin(angleSquare)

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in ("CenterMotion-"+str(j),"RightMotion-"+str(j),"LeftMotion-"+str(j),"FrontMotion-"+str(j),"BackMotion-"+str(j)):
            o.select_set(True)
            
    centerMotion.select_set(state=True)
    bpy.context.view_layer.objects.active = centerMotion
    bpy.ops.object.join()
    bpy.data.objects["CenterMotion-"+str(j)].name = "BaseSquareShape-"+str(j)
    
    return centerMotion

def spawnFractal(length,n_max):
    offset = 0
    offsetH = 0
    offsetV = 0
    for i in range(n_max):
        print('start loop fractal pool recursion at index: '+str(i))
        if(i==0):
            offsetH+= 0.5*(length / ((1+2*math.sin(angleSquare))**i))*(1+math.sin(angleSquare))
            spawnSquareShapeFractal(length,0)
        if(i==1):
            baseSquareShape = bpy.context.scene.objects['BaseSquareShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angleSquare))**i))*math.cos(angleSquare)
 
            offsetH += 0.5* (length / ((1+2*math.sin(angleSquare))**i))

            rightMotion.rotation_euler.y = angleSquare
            rightMotion.location.x += offsetH
            rightMotion.location.z += -0.5*math.sin(angleSquare) * (length / ((1+2*math.sin(angleSquare))**i))

            leftMotion.rotation_euler.y = -angleSquare
            leftMotion.location.x -= offsetH
            leftMotion.location.z += -0.5*math.sin(angleSquare) * (length / ((1+2*math.sin(angleSquare))**i))

            frontMotion.rotation_euler.x = -angleSquare
            frontMotion.location.y += offsetH
            frontMotion.location.z += -0.5*math.sin(angleSquare) * (length / ((1+2*math.sin(angleSquare))**i))

            backMotion.rotation_euler.x = angleSquare
            backMotion.location.y -= offsetH
            backMotion.location.z += -0.5*math.sin(angleSquare) * (length / ((1+2*math.sin(angleSquare))**i))

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseSquareShape-"+str(i)+"_C",
                "BaseSquareShape-"+str(i)+"_R",
                "BaseSquareShape-"+str(i)+"_L",
                "BaseSquareShape-"+str(i)+"_F",
                "BaseSquareShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseSquareShape-"+str(i)+"_C"].name = "BaseSquareShape-"+str(i)
            
        if(i==2):
            baseSquareShape = bpy.context.scene.objects['BaseSquareShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angleSquare))**i))*math.cos(angleSquare)

            offsetH = 0
            for K in range(i+1):
                if K==0:
                    offsetH += 0.5*(length / ((1+2*math.sin(angleSquare))**K))*(1+math.sin(angleSquare))
                if K>0:
                    offsetH +=(length / ((1+2*math.sin(angleSquare))**K))/2
                    
            offsetV = 0
            for V in range(i):
                if(i-V==2):
                    offsetV += 0.5*(length / ((1+2*math.sin(angleSquare))**(i-V)))*math.sin(angleSquare)
                else:
                    offsetV +=(length / ((1+2*math.sin(angleSquare))**1))*math.sin(angleSquare)
                    
            if(offsetV==(0.5*(length / ((1+2*math.sin(angleSquare))**2))*math.sin(angleSquare) + (length / ((1+2*math.sin(angleSquare))**1))*math.sin(angleSquare))):
                print('test ok')

                    
            rightMotion.rotation_euler.y = angleSquare
            rightMotion.location.x += offsetH
            rightMotion.location.z -= offsetV

            leftMotion.rotation_euler.y = -angleSquare
            leftMotion.location.x -= offsetH
            leftMotion.location.z -= offsetV

            frontMotion.rotation_euler.x = -angleSquare
            frontMotion.location.y += offsetH
            frontMotion.location.z += -offsetV

            backMotion.rotation_euler.x = angleSquare
            backMotion.location.y -= offsetH
            backMotion.location.z += -offsetV

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseSquareShape-"+str(i)+"_C",
                "BaseSquareShape-"+str(i)+"_R",
                "BaseSquareShape-"+str(i)+"_L",
                "BaseSquareShape-"+str(i)+"_F",
                "BaseSquareShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseSquareShape-"+str(i)+"_C"].name = "BaseSquareShape-"+str(i)
            
        if(i>2):
            baseSquareShape = bpy.context.scene.objects['BaseSquareShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseSquareShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseSquareShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseSquareShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angleSquare))**i))*math.cos(angleSquare)

            offsetH = 0
            for K in range(i+1):
                if K==0:
                    offsetH += 0.5*(length / ((1+2*math.sin(angleSquare))**K))*(1+math.sin(angleSquare))
                if K>0:
                    offsetH +=  (length / ((1+2*math.sin(angleSquare))**K))/2
   
            offsetV = 0
            for V in range(i):
                if(V>0):
                    offsetV += (length / ((1+2*math.sin(angleSquare))**V))*math.cos(angleSquare)
                    
            if(offsetH== (0.5*(length / ((1+2*math.sin(angleSquare))**0))*(1+math.sin(angleSquare))+(length / ((1+2*math.sin(angleSquare))**1))/2+(length / ((1+2*math.sin(angleSquare))**2))/2+(length / ((1+2*math.sin(angleSquare))**3))/2)):
                print('test ok')

            rightMotion.location.z -= offsetV
            leftMotion.location.z -= offsetV
            frontMotion.location.z -= offsetV
            backMotion.location.z -= offsetV

            rightMotion.rotation_euler.y = angleSquare
            rightMotion.location.x += offsetH
            rightMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            leftMotion.rotation_euler.y = -angleSquare
            leftMotion.location.x -= offsetH
            leftMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            frontMotion.rotation_euler.x = -angleSquare
            frontMotion.location.y += offsetH
            frontMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            backMotion.rotation_euler.x = angleSquare
            backMotion.location.y -= offsetH
            backMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseSquareShape-"+str(i)+"_C",
                "BaseSquareShape-"+str(i)+"_R",
                "BaseSquareShape-"+str(i)+"_L",
                "BaseSquareShape-"+str(i)+"_F",
                "BaseSquareShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseSquareShape-"+str(i)+"_C"].name = "BaseSquareShape-"+str(i)

#####################################################################################################################################################################
###################################################################### PENTAGON POLYGON BASE TYPE FRACTAL CODE ########################################################
##################################################################################################################################################################### 

def basePentagonShape(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
        origin + Vector((length*math.sin(216*math.pi/180),length*math.cos(216*math.pi/180),0)),
        origin + Vector((length*math.sin(288*math.pi/180),length*math.cos(288*math.pi/180),0)),
        origin + Vector((0,length,0)),
        origin + Vector((length*math.sin(72*math.pi/180),length*math.cos(72*math.pi/180),0)),
        origin + Vector((length*math.sin(144*math.pi/180),length*math.cos(144*math.pi/180),0)),

        ]
    edges=[]
    faces=[
        (0,1,2,3,4),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

#initialization
length = 100
anglePentagon = 72*math.pi/180

primaryPentagonPivotPoints = [
    Vector((0.5*length*math.sin(72*math.pi/180),0.5*length*math.cos(72*math.pi/180),0)),
    Vector((0.5*(length*math.sin(144*math.pi/180) - length*math.sin(72*math.pi/180)),0.5*(length*math.cos(144*math.pi/180) - length*math.cos(72*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(216*math.pi/180)- length*math.sin(144*math.pi/180)),0.5*(length*math.cos(216*math.pi/180)-length*math.cos(144*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(288*math.pi/180)- length*math.sin(216*math.pi/180)),0.5*(length*math.cos(288*math.pi/180)-length*math.cos(216*math.pi/180)),0)),
    Vector((0.5*length*math.sin(288*math.pi/180),0.5*(length*math.cos(288*math.pi/180) - length),0)),
]

##cursor3D setting
origin = (0,0,0)

def spawnPentagonShapeFractal(length, j):
    #Initialize the geometry shape
    basePentagonShape('CenterMotion-'+str(j), length)
    centerMotion = bpy.context.scene.objects['CenterMotion-'+str(j)]

    basePentagonShape('BMotion-'+str(0), length)
    bMotion = bpy.context.scene.objects['BMotion-'+str(0)]
    bMotion.rotation_euler.x +=  math.pi + 0.5*anglePentagon + 2*math.pi/180
    bMotion.location.y = -length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
    bMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180)

    basePentagonShape('BRightMotion-'+str(0), length)
    brightMotion = bpy.context.scene.objects['BRightMotion-'+str(0)]
    brightMotion.rotation_euler.x +=  math.pi + 0.5*anglePentagon + 2*math.pi/180
    brightMotion.rotation_euler.z += anglePentagon
    brightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(72*math.pi/180)
    brightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(72*math.pi/180)
    brightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180)

    basePentagonShape('RightMotion-'+str(0), length)
    rightMotion = bpy.context.scene.objects['RightMotion-'+str(0)]
    rightMotion.rotation_euler.x +=  math.pi + 0.5*anglePentagon + 2*math.pi/180
    rightMotion.rotation_euler.z += 2*anglePentagon
    rightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(144*math.pi/180)
    rightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(144*math.pi/180)
    rightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180)

    basePentagonShape('LeftMotion-'+str(0), length)
    leftMotion = bpy.context.scene.objects['LeftMotion-'+str(0)]
    leftMotion.rotation_euler.x +=  math.pi + 0.5*anglePentagon + 2*math.pi/180
    leftMotion.rotation_euler.z += 3*anglePentagon
    leftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(216*math.pi/180)
    leftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(216*math.pi/180)
    leftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180)

    basePentagonShape('BLeftMotion-'+str(0), length)
    bleftMotion = bpy.context.scene.objects['BLeftMotion-'+str(0)]
    bleftMotion.rotation_euler.x +=  math.pi + 0.5*anglePentagon + 2*math.pi/180
    bleftMotion.rotation_euler.z += 4*anglePentagon
    bleftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(288*math.pi/180)
    bleftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(288*math.pi/180)
    bleftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180)

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in ("CenterMotion-"+str(j),"BMotion-"+str(j),"BRightMotion-"+str(j),"RightMotion-"+str(j),"LeftMotion-"+str(j), "BLeftMotion-"+str(j)):
            o.select_set(True)
            
    centerMotion.select_set(state=True)
    bpy.context.view_layer.objects.active = centerMotion
    bpy.ops.object.join()
    bpy.data.objects["CenterMotion-"+str(j)].name = "BasePentagonShape-"+str(j)
    
    return centerMotion

def spawnPentagonFractal(length,n_max):
    offset = 0
    offsetBH = 0
    offsetH_x = 0
    offsetH_y = 0
    offsetV = 0
    for i in range(n_max):
        print('start loop fractal pool recursion at index: '+str(i))
        if(i==0):
            #offsetH+= 0.5*(length / ((1+2*math.cos(0.5*anglePentagon*(math.cos(anglePentagon +2*math.pi/180)**2)))**i))
            spawnPentagonShapeFractal(length,0)
        if(i==1):
            basePentagonShape = bpy.context.scene.objects['BasePentagonShape-'+str(i-1)]
            for cloneI in range(6):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(6):
                if(partI==0):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_B"
                if(partI==2):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BR"
                if(partI==3):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_R"
                if(partI==4):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_L"
                if(partI==5):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BL"
                    
            centerMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_C']
            baseMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_B']
            brightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BR']
            rightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_L']
            bleftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BL']

            centerMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            baseMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            brightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            rightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            leftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            bleftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)

            centerMotion.location.z += (length / ((math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))**i))*((1+math.cos(anglePentagon*0.5))*math.sin(0.5*anglePentagon + 2*math.pi/180))
            centerMotion.rotation_euler.z += anglePentagon/2 

            baseMotion.rotation_euler.x +=  0.5*anglePentagon + 2*math.pi/180
            offset_BM_y = -((length / ((math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))**i))*((1+math.cos(anglePentagon*0.5))*math.sin(0.5*anglePentagon + 2*math.pi/180)))*math.cos(52*math.pi/180)
            offset_BM_z = ((length / ((math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))**i))*((1+math.cos(anglePentagon*0.5))*math.sin(0.5*anglePentagon + 2*math.pi/180)))*math.sin(52*math.pi/180)
            baseMotion.location.y = -length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180) + offset_BM_y
            baseMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            brightMotion.rotation_euler.x +=  0.5*anglePentagon + 2*math.pi/180
            brightMotion.rotation_euler.z += anglePentagon

            brightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(72*math.pi/180) - offset_BM_y*math.sin(anglePentagon)
            brightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(72*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            brightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z


            rightMotion.rotation_euler.x +=  0.5*anglePentagon + 2*math.pi/180
            rightMotion.rotation_euler.z += 2*anglePentagon
            rightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(144*math.pi/180) - offset_BM_y*math.sin(2*anglePentagon)
            rightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(144*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            rightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            leftMotion.rotation_euler.x += 0.5*anglePentagon + 2*math.pi/180
            leftMotion.rotation_euler.z += 3*anglePentagon
            leftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(216*math.pi/180) + offset_BM_y*math.sin(2*anglePentagon)
            leftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(216*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            leftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            bleftMotion.rotation_euler.x += 0.5*anglePentagon + 2*math.pi/180
            bleftMotion.rotation_euler.z += 4*anglePentagon
            bleftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(288*math.pi/180) + offset_BM_y*math.sin(anglePentagon)
            bleftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(288*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            bleftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z


            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BasePentagonShape-"+str(i)+"_C",
                "BasePentagonShape-"+str(i)+"_B",
                "BasePentagonShape-"+str(i)+"_BR",
                "BasePentagonShape-"+str(i)+"_R",
                "BasePentagonShape-"+str(i)+"_L",
                "BasePentagonShape-"+str(i)+"_BL",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BasePentagonShape-"+str(i)+"_C"].name = "BasePentagonShape-"+str(i)  
            
        if(i==2):
            BasePentagonShape = bpy.context.scene.objects['BasePentagonShape-'+str(i-1)]
            for cloneI in range(6):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(6):
                if(partI==0):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_B"
                if(partI==2):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BR"
                if(partI==3):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_R"
                if(partI==4):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_L"
                if(partI==5):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BL"
                    
            centerMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_C']
            baseMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_B']
            brightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BR']
            rightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_L']
            bleftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BL']

            centerMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            baseMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            brightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            rightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            leftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            bleftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)

            offset_z = (length / ((math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))**i))*((1+math.cos(anglePentagon*0.5))*math.sin(0.5*anglePentagon + 2*math.pi/180))

            centerMotion.location.z += offset_z
            centerMotion.rotation_euler.z += anglePentagon/2
            
            baseMotion.rotation_euler.z =  math.pi
            baseMotion.rotation_euler.x +=  -0.5*anglePentagon - 2*math.pi/180
            offset_BM_y = -offset_z*math.cos(52*math.pi/180)
            offset_BM_z = offset_z*math.sin(52*math.pi/180)    
            baseMotion.location.y = -length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180) + offset_BM_y
            baseMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z
 
            brightMotion.rotation_euler.x =  -0.5*anglePentagon - 2*math.pi/180
            brightMotion.rotation_euler.z = math.pi +anglePentagon
            brightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(72*math.pi/180) - offset_BM_y*math.sin(anglePentagon)
            brightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(72*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            brightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z


            rightMotion.rotation_euler.x =  -0.5*anglePentagon - 2*math.pi/180
            rightMotion.rotation_euler.z = -0.5*anglePentagon
            rightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(144*math.pi/180) - offset_BM_y*math.sin(2*anglePentagon)
            rightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(144*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            rightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z 

            leftMotion.rotation_euler.x =  -0.5*anglePentagon - 2*math.pi/180
            leftMotion.rotation_euler.z = 0.5*anglePentagon
            leftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(216*math.pi/180) + offset_BM_y*math.sin(2*anglePentagon)
            leftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(216*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            leftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            bleftMotion.rotation_euler.x = -0.5*anglePentagon - 2*math.pi/180
            bleftMotion.rotation_euler.z = 468*math.pi/180
            bleftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(288*math.pi/180) + offset_BM_y*math.sin(anglePentagon)
            bleftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(288*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            bleftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            offset_corrector = 2.2388

            baseMotion.location.y += offset_BM_y*offset_corrector
            baseMotion.location.z += offset_BM_z*offset_corrector
            
            brightMotion.location.x -= offset_BM_y*math.sin(anglePentagon)*offset_corrector
            brightMotion.location.y += offset_BM_y*math.cos(anglePentagon)*offset_corrector
            brightMotion.location.z += offset_BM_z*offset_corrector
            
            rightMotion.location.x -= offset_BM_y*math.sin(2*anglePentagon)*offset_corrector
            rightMotion.location.y += offset_BM_y*math.cos(2*anglePentagon)*offset_corrector
            rightMotion.location.z += offset_BM_z*offset_corrector
                        
            leftMotion.location.x += offset_BM_y*math.sin(2*anglePentagon)*offset_corrector
            leftMotion.location.y += offset_BM_y*math.cos(2*anglePentagon)*offset_corrector
            leftMotion.location.z += offset_BM_z*offset_corrector
            
            bleftMotion.location.x += offset_BM_y*math.sin(anglePentagon)*offset_corrector
            bleftMotion.location.y += offset_BM_y*math.cos(anglePentagon)*offset_corrector
            bleftMotion.location.z += offset_BM_z*offset_corrector
            
            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BasePentagonShape-"+str(i)+"_C",
                "BasePentagonShape-"+str(i)+"_B",
                "BasePentagonShape-"+str(i)+"_BR",
                "BasePentagonShape-"+str(i)+"_R",
                "BasePentagonShape-"+str(i)+"_L",
                "BasePentagonShape-"+str(i)+"_BL",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BasePentagonShape-"+str(i)+"_C"].name = "BasePentagonShape-"+str(i)
        if(i==3):
            BasePentagonShape = bpy.context.scene.objects['BasePentagonShape-'+str(i-1)]
            for cloneI in range(6):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(6):
                if(partI==0):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_B"
                if(partI==2):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BR"
                if(partI==3):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_R"
                if(partI==4):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_L"
                if(partI==5):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_BL"
                    
            centerMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_C']
            baseMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_B']
            brightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BR']
            rightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_L']
            bleftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_BL']

            centerMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            baseMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            brightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            rightMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            leftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)
            bleftMotion.scale /= math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180)

            offset_z = (length / ((math.cos(0.5*anglePentagon) + math.cos(0.5*anglePentagon + 2*math.pi/180) + math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))**i))*((1+math.cos(anglePentagon*0.5))*math.sin(0.5*anglePentagon + 2*math.pi/180))

            centerMotion.location.z += offset_z
            centerMotion.rotation_euler.z += anglePentagon/2
           
            baseMotion.rotation_euler.z =  math.pi
            baseMotion.rotation_euler.x +=  -0.5*anglePentagon - 2*math.pi/180
            offset_BM_y = -offset_z*math.cos(52*math.pi/180)
            offset_BM_z = offset_z*math.sin(52*math.pi/180)    
            baseMotion.location.y = -length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180) + offset_BM_y
            baseMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z
 
            brightMotion.rotation_euler.x =  -0.5*anglePentagon - 2*math.pi/180
            brightMotion.rotation_euler.z = math.pi +anglePentagon
            brightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(72*math.pi/180) - offset_BM_y*math.sin(anglePentagon)
            brightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(72*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            brightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z


            rightMotion.rotation_euler.x =  -0.5*anglePentagon - 2*math.pi/180
            rightMotion.rotation_euler.z = math.pi -0.5*anglePentagon
            rightMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(144*math.pi/180) - offset_BM_y*math.sin(2*anglePentagon)
            rightMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(144*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            rightMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z 

            leftMotion.rotation_euler.x =  0.5*anglePentagon + 2*math.pi/180
            leftMotion.rotation_euler.z = 216*math.pi/180
            leftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(216*math.pi/180) + offset_BM_y*math.sin(2*anglePentagon)
            leftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(216*math.pi/180) + offset_BM_y*math.cos(2*anglePentagon)
            leftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            bleftMotion.rotation_euler.x = 0.5*anglePentagon + 2*math.pi/180
            bleftMotion.rotation_euler.z = -anglePentagon
            bleftMotion.location.x = -(-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.sin(288*math.pi/180) + offset_BM_y*math.sin(anglePentagon)
            bleftMotion.location.y = (-length*math.cos(anglePentagon*0.5) - length*math.cos(0.5*anglePentagon)*math.cos(0.5*anglePentagon + 2*math.pi/180))*math.cos(288*math.pi/180) + offset_BM_y*math.cos(anglePentagon)
            bleftMotion.location.z = -length*math.cos(0.5*anglePentagon)*math.sin(0.5*anglePentagon + 2*math.pi/180) + offset_BM_z

            baseMotion.rotation_euler.x += anglePentagon
            baseMotion.rotation_euler.z += math.pi
            
            brightMotion.rotation_euler.x += 2*(0.5*anglePentagon +2*math.pi/180)
            brightMotion.rotation_euler.z += math.pi
            
            rightMotion.rotation_euler.x += 2*(0.5*anglePentagon +2*math.pi/180)

             
            offset_corrector = 2.2388*3.09834

            baseMotion.location.y += offset_BM_y*offset_corrector
            baseMotion.location.z += offset_BM_z*offset_corrector
            
            brightMotion.location.x -= offset_BM_y*math.sin(anglePentagon)*offset_corrector
            brightMotion.location.y += offset_BM_y*math.cos(anglePentagon)*offset_corrector
            brightMotion.location.z += offset_BM_z*offset_corrector
            
            rightMotion.location.x -= offset_BM_y*math.sin(2*anglePentagon)*offset_corrector
            rightMotion.location.y += offset_BM_y*math.cos(2*anglePentagon)*offset_corrector
            rightMotion.location.z += offset_BM_z*offset_corrector
                        
            leftMotion.location.x += offset_BM_y*math.sin(2*anglePentagon)*offset_corrector
            leftMotion.location.y += offset_BM_y*math.cos(2*anglePentagon)*offset_corrector
            leftMotion.location.z += offset_BM_z*offset_corrector
            
            bleftMotion.location.x += offset_BM_y*math.sin(anglePentagon)*offset_corrector
            bleftMotion.location.y += offset_BM_y*math.cos(anglePentagon)*offset_corrector
            bleftMotion.location.z += offset_BM_z*offset_corrector
            
            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BasePentagonShape-"+str(i)+"_C",
                "BasePentagonShape-"+str(i)+"_B",
                "BasePentagonShape-"+str(i)+"_BR",
                "BasePentagonShape-"+str(i)+"_R",
                "BasePentagonShape-"+str(i)+"_L",
                "BasePentagonShape-"+str(i)+"_BL",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BasePentagonShape-"+str(i)+"_C"].name = "BasePentagonShape-"+str(i)    
        if(i>3):
            baseSquareShape = bpy.context.scene.objects['BasePentagonShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BasePentagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BasePentagonShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BasePentagonShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angleSquare))**i))*math.cos(angleSquare)

            offsetH = 0
            for K in range(i+1):
                if K==0:
                    offsetH += 0.5*(length / ((1+2*math.sin(angleSquare))**K))*(1+math.sin(angleSquare))
                if K>0:
                    offsetH +=  (length / ((1+2*math.sin(angleSquare))**K))/2
   
            offsetV = 0
            for V in range(i):
                if(V>0):
                    offsetV += (length / ((1+2*math.sin(angleSquare))**V))*math.cos(angleSquare)
                    
            if(offsetH== (0.5*(length / ((1+2*math.sin(angleSquare))**0))*(1+math.sin(angleSquare))+(length / ((1+2*math.sin(angleSquare))**1))/2+(length / ((1+2*math.sin(angleSquare))**2))/2+(length / ((1+2*math.sin(angleSquare))**3))/2)):
                print('test ok')

            rightMotion.location.z -= offsetV
            leftMotion.location.z -= offsetV
            frontMotion.location.z -= offsetV
            backMotion.location.z -= offsetV

            rightMotion.rotation_euler.y = angleSquare
            rightMotion.location.x += offsetH
            rightMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            leftMotion.rotation_euler.y = -angleSquare
            leftMotion.location.x -= offsetH
            leftMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            frontMotion.rotation_euler.x = -angleSquare
            frontMotion.location.y += offsetH
            frontMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            backMotion.rotation_euler.x = angleSquare
            backMotion.location.y -= offsetH
            backMotion.location.z += -0.5*(length / ((1+2*math.sin(angleSquare))**i))*math.sin(angleSquare)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BasePentagonShape-"+str(i)+"_C",
                "BasePentagonShape-"+str(i)+"_R",
                "BasePentagonShape-"+str(i)+"_L",
                "BasePentagonShape-"+str(i)+"_F",
                "BasePentagonShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BasePentagonShape-"+str(i)+"_C"].name = "BasePentagonShape-"+str(i)            

#####################################################################################################################################################################
###################################################################### HEXAGON POLYGON BASE TYPE FRACTAL CODE ########################################################
##################################################################################################################################################################### 

def baseHexagonShape(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
        origin + Vector((length*math.sin(240*math.pi/180),length*math.cos(240*math.pi/180),0)),
        origin + Vector((length*math.sin(300*math.pi/180),length*math.cos(300*math.pi/180),0)),
        origin + Vector((0,length,0)),
        origin + Vector((length*math.sin(60*math.pi/180),length*math.cos(60*math.pi/180),0)),
        origin + Vector((length*math.sin(120*math.pi/180),length*math.cos(120*math.pi/180),0)),
        origin + Vector((length*math.sin(180*math.pi/180),length*math.cos(180*math.pi/180),0)),

        ]
    edges=[]
    faces=[
        (0,1,2,3,4,5),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

#initialization
length = 100
angleHexagon = 60*math.pi/180
angleCorrection = -24

primaryPentagonPivotPoints = [
    Vector((0.5*length*math.sin(60*math.pi/180),0.5*length*math.cos(60*math.pi/180),0)),
    Vector((0.5*(length*math.sin(120*math.pi/180) - length*math.sin(60*math.pi/180)),0.5*(length*math.cos(120*math.pi/180) - length*math.cos(60*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(180*math.pi/180)- length*math.sin(120*math.pi/180)),0.5*(length*math.cos(180*math.pi/180)-length*math.cos(120*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(240*math.pi/180)- length*math.sin(180*math.pi/180)),0.5*(length*math.cos(240*math.pi/180)-length*math.cos(180*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(300*math.pi/180)- length*math.sin(240*math.pi/180)),0.5*(length*math.cos(300*math.pi/180)-length*math.cos(240*math.pi/180)),0)),
    Vector((-0.5*length*math.sin(300*math.pi/180),-0.5*(length*math.cos(300*math.pi/180) - length),0)),
]

##cursor3D setting
origin = (0,0,0)

def spawnHexagonShapeFractal(length, j):
    #Initialize the geometry shape
    baseHexagonShape('CenterMotion-'+str(j), length)
    centerMotion = bpy.context.scene.objects['CenterMotion-'+str(j)]

    baseHexagonShape('leftMotion-'+str(0), length)
    leftMotion = bpy.context.scene.objects['leftMotion-'+str(0)]
    leftMotion.rotation_euler.y += -( 0.5*angleHexagon + angleCorrection*math.pi/180)
    leftMotion.location.x = -length*math.cos(0.5*angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
    leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)
    
    baseHexagonShape('front_leftMotion-'+str(0), length)
    front_leftMotion = bpy.context.scene.objects['front_leftMotion-'+str(0)]
    front_leftMotion.rotation_euler.y += -( 0.5*angleHexagon + angleCorrection*math.pi/180)
    front_leftMotion.rotation_euler.z += -angleHexagon
    front_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
    front_leftMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
    front_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)
    
    baseHexagonShape('back_leftMotion-'+str(0), length)
    back_leftMotion = bpy.context.scene.objects['back_leftMotion-'+str(0)]
    back_leftMotion.rotation_euler.y += -( 0.5*angleHexagon + angleCorrection*math.pi/180)
    back_leftMotion.rotation_euler.z += angleHexagon
    back_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
    back_leftMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
    back_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)

    baseHexagonShape('rightMotion-'+str(0), length)
    rightMotion = bpy.context.scene.objects['rightMotion-'+str(0)]
    rightMotion.rotation_euler.y += ( 0.5*angleHexagon + angleCorrection*math.pi/180)
    rightMotion.location.x = length*math.cos(0.5*angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
    rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)
    
    baseHexagonShape('front_rightMotion-'+str(0), length)
    front_rightMotion = bpy.context.scene.objects['front_rightMotion-'+str(0)]
    front_rightMotion.rotation_euler.y += ( 0.5*angleHexagon + angleCorrection*math.pi/180)
    front_rightMotion.rotation_euler.z += angleHexagon
    front_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
    front_rightMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
    front_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)
    
    baseHexagonShape('back_rightMotion-'+str(0), length)
    back_rightMotion = bpy.context.scene.objects['back_rightMotion-'+str(0)]
    back_rightMotion.rotation_euler.y += ( 0.5*angleHexagon + angleCorrection*math.pi/180)
    back_rightMotion.rotation_euler.z += -angleHexagon
    back_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
    back_rightMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
    back_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180)

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in ("CenterMotion-"+str(j),"leftMotion-"+str(j),"front_leftMotion-"+str(j),"back_leftMotion-"+str(j),"rightMotion-"+str(j), "front_rightMotion-"+str(j), "back_rightMotion-"+str(j)):
            o.select_set(True)
            
    centerMotion.select_set(state=True)
    bpy.context.view_layer.objects.active = centerMotion
    bpy.ops.object.join()
    bpy.data.objects["CenterMotion-"+str(j)].name = "BaseHexagonShape-"+str(j)
    
    return centerMotion

def spawnHexagonFractal(length,n_max):
    offset = 0
    offsetBH = 0
    offsetH_x = 0
    offsetH_y = 0
    offsetV = 0
    for i in range(n_max):
        print('start loop fractal pool recursion at index: '+str(i))
        if(i==0):
            spawnHexagonShapeFractal(length,0)
        if(i==1):
            basePentagonShape = bpy.context.scene.objects['BaseHexagonShape-'+str(i-1)]
            for cloneI in range(7):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(7):
                if(partI==0):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BL"
                if(partI==3):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FL"
                if(partI==4):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_R"
                if(partI==5):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BR"
                if(partI==6):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FR"

            centerMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_L']
            back_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BL']
            front_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FL']
            rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_R']
            back_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BR']
            front_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FR']        

            centerMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)

            centerMotion.location.z += (length / (1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)) + length*0.05)

            leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            leftMotion.location.x = -length*math.cos(0.5*angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            front_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_leftMotion.rotation_euler.z += -angleHexagon
            front_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_leftMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            back_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_leftMotion.rotation_euler.z += angleHexagon
            back_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_leftMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            rightMotion.location.x = length*math.cos(0.5*angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            front_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_rightMotion.rotation_euler.z += angleHexagon
            front_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_rightMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            back_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_rightMotion.rotation_euler.z += -angleHexagon
            back_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_rightMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*0.05

            leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseHexagonShape-"+str(i)+"_C",
                "BaseHexagonShape-"+str(i)+"_L",
                "BaseHexagonShape-"+str(i)+"_BL",
                "BaseHexagonShape-"+str(i)+"_FL",
                "BaseHexagonShape-"+str(i)+"_R",
                "BaseHexagonShape-"+str(i)+"_BR",
                "BaseHexagonShape-"+str(i)+"_FR",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5],nameList[6]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseHexagonShape-"+str(i)+"_C"].name = "BaseHexagonShape-"+str(i)  
            
        if(i==2):
            basePentagonShape = bpy.context.scene.objects['BaseHexagonShape-'+str(i-1)]
            for cloneI in range(7):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(7):
                if(partI==0):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BL"
                if(partI==3):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FL"
                if(partI==4):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_R"
                if(partI==5):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BR"
                if(partI==6):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FR"

            centerMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_L']
            back_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BL']
            front_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FL']
            rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_R']
            back_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BR']
            front_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FR']        

            centerMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)

            centerMotion.location.z += (length / (1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)) - length*0.19)

            leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            leftMotion.location.x = -length*math.cos(0.5*angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            front_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_leftMotion.rotation_euler.z += -angleHexagon
            front_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_leftMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            back_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_leftMotion.rotation_euler.z += angleHexagon
            back_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_leftMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            rightMotion.location.x = length*math.cos(0.5*angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            front_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_rightMotion.rotation_euler.z += angleHexagon
            front_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_rightMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            back_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_rightMotion.rotation_euler.z += -angleHexagon
            back_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_rightMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.19

            leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseHexagonShape-"+str(i)+"_C",
                "BaseHexagonShape-"+str(i)+"_L",
                "BaseHexagonShape-"+str(i)+"_BL",
                "BaseHexagonShape-"+str(i)+"_FL",
                "BaseHexagonShape-"+str(i)+"_R",
                "BaseHexagonShape-"+str(i)+"_BR",
                "BaseHexagonShape-"+str(i)+"_FR",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5],nameList[6]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseHexagonShape-"+str(i)+"_C"].name = "BaseHexagonShape-"+str(i)  
        if(i==3):
            basePentagonShape = bpy.context.scene.objects['BaseHexagonShape-'+str(i-1)]
            for cloneI in range(7):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(7):
                if(partI==0):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BL"
                if(partI==3):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FL"
                if(partI==4):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_R"
                if(partI==5):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BR"
                if(partI==6):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FR"

            centerMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_L']
            back_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BL']
            front_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FL']
            rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_R']
            back_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BR']
            front_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FR']        

            centerMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)

            centerMotion.location.z += (length / (1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)) - length*0.281)

            leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            leftMotion.location.x = -length*math.cos(0.5*angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            front_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_leftMotion.rotation_euler.z += -angleHexagon
            front_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_leftMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            back_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_leftMotion.rotation_euler.z += angleHexagon
            back_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_leftMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            rightMotion.location.x = length*math.cos(0.5*angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            front_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_rightMotion.rotation_euler.z += angleHexagon
            front_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_rightMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            back_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_rightMotion.rotation_euler.z += -angleHexagon
            back_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_rightMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.281

            leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseHexagonShape-"+str(i)+"_C",
                "BaseHexagonShape-"+str(i)+"_L",
                "BaseHexagonShape-"+str(i)+"_BL",
                "BaseHexagonShape-"+str(i)+"_FL",
                "BaseHexagonShape-"+str(i)+"_R",
                "BaseHexagonShape-"+str(i)+"_BR",
                "BaseHexagonShape-"+str(i)+"_FR",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5],nameList[6]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseHexagonShape-"+str(i)+"_C"].name = "BaseHexagonShape-"+str(i) 
   
        if(i==4):
            basePentagonShape = bpy.context.scene.objects['BaseHexagonShape-'+str(i-1)]
            for cloneI in range(7):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(7):
                if(partI==0):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BL"
                if(partI==3):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FL"
                if(partI==4):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_R"
                if(partI==5):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_BR"
                if(partI==6):
                    bpy.data.objects["BaseHexagonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseHexagonShape-"+str(i)+"_FR"

            centerMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_L']
            back_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BL']
            front_leftMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FL']
            rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_R']
            back_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_BR']
            front_rightMotion = bpy.context.scene.objects['BaseHexagonShape-'+str(i)+'_FR']        

            centerMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_leftMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            back_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            front_rightMotion.scale /= 1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)

            centerMotion.location.z += (length / (1 + 2*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)) - length*0.305)

            leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            leftMotion.location.x = -length*math.cos(0.5*angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            front_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_leftMotion.rotation_euler.z += -angleHexagon
            front_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_leftMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            back_leftMotion.rotation_euler.y += ( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_leftMotion.rotation_euler.z += angleHexagon
            back_leftMotion.location.x += -length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) - length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_leftMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            rightMotion.location.x = length*math.cos(0.5*angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)
            rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            front_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            front_rightMotion.rotation_euler.z += angleHexagon
            front_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            front_rightMotion.location.y += length*math.cos(0.5*angleHexagon)*math.sin(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.sin(angleHexagon)
            front_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            back_rightMotion.rotation_euler.y += -( 0.5*angleHexagon*180/math.pi + angleCorrection)
            back_rightMotion.rotation_euler.z += -angleHexagon
            back_rightMotion.location.x += length*math.cos(0.5*angleHexagon)*math.cos(angleHexagon) + length*math.cos(0.5*angleHexagon)*math.cos(0.5*angleHexagon + angleCorrection*math.pi/180)*math.cos(angleHexagon)
            back_rightMotion.location.y += -2*length + length*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += -length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) - length*0.305

            leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_leftMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            front_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)
            back_rightMotion.location.z += 0.5*(-2*length*math.cos(0.5*angleHexagon)*math.sin(0.5*angleHexagon + angleCorrection*math.pi/180) + length*math.cos(0.5*angleHexagon))*math.sin(0.5*angleHexagon)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseHexagonShape-"+str(i)+"_C",
                "BaseHexagonShape-"+str(i)+"_L",
                "BaseHexagonShape-"+str(i)+"_BL",
                "BaseHexagonShape-"+str(i)+"_FL",
                "BaseHexagonShape-"+str(i)+"_R",
                "BaseHexagonShape-"+str(i)+"_BR",
                "BaseHexagonShape-"+str(i)+"_FR",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4],nameList[5],nameList[6]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseHexagonShape-"+str(i)+"_C"].name = "BaseHexagonShape-"+str(i) 


#####################################################################################################################################################################
###################################################################### HEPTAGON POLYGON BASE TYPE FRACTAL CODE ########################################################
##################################################################################################################################################################### 




#####################################################################################################################################################################
###################################################################### OCTOGON POLYGON BASE TYPE FRACTAL CODE ########################################################
##################################################################################################################################################################### 
angleOctogon = 45*math.pi/180

def baseOctogonShape(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
        origin + Vector((length*math.sin(22.5*math.pi/180),-length*math.cos(22.5*math.pi/180),0)),
        origin + Vector((length*math.cos(22.5*math.pi/180),-length*math.sin(22.5*math.pi/180),0)),
        origin + Vector((length*math.cos(22.5*math.pi/180),length*math.sin(22.5*math.pi/180),0)),
        origin + Vector((length*math.sin(22.5*math.pi/180),length*math.cos(22.5*math.pi/180),0)),
        origin + Vector((-length*math.sin(22.5*math.pi/180),length*math.cos(22.5*math.pi/180),0)),
        origin + Vector((-length*math.cos(22.5*math.pi/180),length*math.sin(22.5*math.pi/180),0)),
        origin + Vector((-length*math.cos(22.5*math.pi/180),-length*math.sin(22.5*math.pi/180),0)),
        origin + Vector((-length*math.sin(22.5*math.pi/180),-length*math.cos(22.5*math.pi/180),0)),
        ]
    edges=[]
    faces=[
        (0,1,2,3,4,5,6,7),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

#initialization
length = 100

angleCorrection = 0

primaryOctogonPivotPoints = [
    Vector((0.5*((length*math.cos(22.5*math.pi/180) - length*math.sin(22.5*math.pi/180))),0.5*(-length*math.sin(22.5*math.pi/180) + length*math.cos(22.5*math.pi/180)),0)),
    Vector((0.5*(length*math.cos(22.5*math.pi/180) - (length*math.cos(22.5*math.pi/180))),0.5*(length*math.sin(22.5*math.pi/180) + length*math.sin(22.5*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(22.5*math.pi/180)- length*math.cos(22.5*math.pi/180)),0.5*(length*math.cos(22.5*math.pi/180)- length*math.sin(22.5*math.pi/180)),0)),
    Vector((0.5*(-length*math.sin(22.5*math.pi/180)- length*math.sin(22.5*math.pi/180)),0.5*(length*math.cos(22.5*math.pi/180)- length*math.cos(22.5*math.pi/180)),0)),
    Vector((0.5*(-length*math.cos(22.5*math.pi/180) + length*math.sin(22.5*math.pi/180)),0.5*(-length*math.cos(22.5*math.pi/180)-length*math.cos(22.5*math.pi/180)),0)),
    Vector((0.5*(-length*math.cos(22.5*math.pi/180) + length*math.cos(22.5*math.pi/180)),0.5*(-length*math.cos(22.5*math.pi/180) + length*math.cos(22.5*math.pi/180)),0)),
    Vector((0.5*(-length*math.sin(22.5*math.pi/180) + length*math.cos(22.5*math.pi/180)),0.5*(-length*math.sin(22.5*math.pi/180) + length*math.cos(22.5*math.pi/180)),0)),
    Vector((0.5*(length*math.sin(22.5*math.pi/180) + length*math.sin(22.5*math.pi/180)),0.5*(-length*math.cos(22.5*math.pi/180) + length*math.sin(22.5*math.pi/180)),0)),
]

##cursor3D setting
origin = (0,0,0)

def spawnOctogonShapeFractal(length, j):
    #Initialize the geometry shape
    baseOctogonShape('CenterMotion-'+str(j), length)
    centerMotion = bpy.context.scene.objects['CenterMotion-'+str(j)]

    baseOctogonShape('leftMotion-'+str(0), length)
    leftMotion = bpy.context.scene.objects['leftMotion-'+str(0)]
    leftMotion.rotation_euler.y += - angleOctogon
    leftMotion.location.x += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)
    leftMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)

    baseOctogonShape('rightMotion-'+str(0), length)
    rightMotion = bpy.context.scene.objects['rightMotion-'+str(0)]
    rightMotion.rotation_euler.y += angleOctogon
    rightMotion.location.x += length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)
    rightMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)

    baseOctogonShape('frontMotion-'+str(0), length)
    frontMotion = bpy.context.scene.objects['frontMotion-'+str(0)]
    frontMotion.rotation_euler.x += - angleOctogon
    frontMotion.location.y += length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)
    frontMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)

    baseOctogonShape('backMotion-'+str(0), length)
    backMotion = bpy.context.scene.objects['backMotion-'+str(0)]
    backMotion.rotation_euler.x += angleOctogon
    backMotion.location.y += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)
    backMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)


    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in ("CenterMotion-"+str(j),"leftMotion-"+str(j),"rightMotion-"+str(j),"frontMotion-"+str(j),"backMotion-"+str(j)):
            o.select_set(True)
            
    centerMotion.select_set(state=True)
    bpy.context.view_layer.objects.active = centerMotion
    bpy.ops.object.join()
    bpy.data.objects["CenterMotion-"+str(j)].name = "BaseOctogonShape-"+str(j)
    
    return centerMotion

def spawnOctogonFractal(length,n_max):
    offset = 0
    offsetBH = 0
    offsetH_x = 0
    offsetH_y = 0
    offsetV = 0
    for i in range(n_max):
        print('start loop fractal pool recursion at index: '+str(i))
        if(i==0):
            spawnOctogonShapeFractal(length,0)
        if(i==1):
            baseOctogonShape = bpy.context.scene.objects['BaseOctogonShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_R"
                if(partI==3):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_B"

            centerMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_L']
            rightMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_R']
            frontMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_B']  

            centerMotion.scale /= 1 + 2*math.cos(angleOctogon)
            leftMotion.scale /= 1 + 2*math.cos(angleOctogon)
            rightMotion.scale /= 1 + 2*math.cos(angleOctogon)
            frontMotion.scale /= 1 + 2*math.cos(angleOctogon)
            backMotion.scale /= 1 + 2*math.cos(angleOctogon)

            offsetH = (2*length/(1 + 2*math.cos(angleOctogon))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)

            centerMotion.location.z += offsetH

            leftMotion.rotation_euler.y += - angleOctogon
            leftMotion.location.x += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - offsetH*math.cos(angleOctogon)
            leftMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon) + offsetH*math.sin(angleOctogon)
             
            rightMotion.rotation_euler.y += angleOctogon
            rightMotion.location.x += length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + offsetH*math.cos(angleOctogon)
            rightMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon) + offsetH*math.sin(angleOctogon)

            frontMotion.rotation_euler.x += - angleOctogon
            frontMotion.location.y += length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + offsetH*math.cos(angleOctogon)
            frontMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon) + offsetH*math.sin(angleOctogon)

            backMotion.rotation_euler.x += angleOctogon
            backMotion.location.y += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - offsetH*math.cos(angleOctogon)
            backMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.sin(angleOctogon) + offsetH*math.sin(angleOctogon)


            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseOctogonShape-"+str(i)+"_C",
                "BaseOctogonShape-"+str(i)+"_L",
                "BaseOctogonShape-"+str(i)+"_R",
                "BaseOctogonShape-"+str(i)+"_B",
                "BaseOctogonShape-"+str(i)+"_F",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseOctogonShape-"+str(i)+"_C"].name = "BaseOctogonShape-"+str(i)   
            
        if(i==2):
            basePentagonShape = bpy.context.scene.objects['BaseOctogonShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_R"
                if(partI==3):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_B"

            centerMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_L']
            rightMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_R']
            frontMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_B']  

            centerMotion.scale /= 1 + 2*math.cos(angleOctogon)
            leftMotion.scale /= 1 + 2*math.cos(angleOctogon)
            rightMotion.scale /= 1 + 2*math.cos(angleOctogon)
            frontMotion.scale /= 1 + 2*math.cos(angleOctogon)
            backMotion.scale /= 1 + 2*math.cos(angleOctogon)

            offsetH = (2*length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            centerMotion.location.z += offsetH

            leftMotion.rotation_euler.y += - angleOctogon
            leftMotion.location.x += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - (2*length/(1 + 2*math.cos(angleOctogon))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            leftMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)
             
            rightMotion.rotation_euler.y += angleOctogon
            rightMotion.location.x += +length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + (2*length/(1 + 2*math.cos(angleOctogon))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            rightMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)

            frontMotion.rotation_euler.x += - angleOctogon
            frontMotion.location.y += length*math.cos(0.5*angleOctogon) + length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + (2*length/(1 + 2*math.cos(angleOctogon))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            frontMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)

            backMotion.rotation_euler.x += angleOctogon
            backMotion.location.y += -length*math.cos(0.5*angleOctogon) - length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - (2*length/(1 + 2*math.cos(angleOctogon))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            backMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon)


            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseOctogonShape-"+str(i)+"_C",
                "BaseOctogonShape-"+str(i)+"_L",
                "BaseOctogonShape-"+str(i)+"_R",
                "BaseOctogonShape-"+str(i)+"_B",
                "BaseOctogonShape-"+str(i)+"_F",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseOctogonShape-"+str(i)+"_C"].name = "BaseOctogonShape-"+str(i)   
        if(i==3):
            basePentagonShape = bpy.context.scene.objects['BaseOctogonShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_R"
                if(partI==3):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_B"

            centerMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_L']
            rightMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_R']
            frontMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_B']  

            centerMotion.scale /= 1 + 2*math.cos(angleOctogon)
            leftMotion.scale /= 1 + 2*math.cos(angleOctogon)
            rightMotion.scale /= 1 + 2*math.cos(angleOctogon)
            frontMotion.scale /= 1 + 2*math.cos(angleOctogon)
            backMotion.scale /= 1 + 2*math.cos(angleOctogon)

            offsetH = (2*length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            centerMotion.location.z += offsetH

            leftMotion.rotation_euler.y += - angleOctogon
            leftMotion.location.x += -length*math.cos(0.5*angleOctogon) - 2*length/((1 + 2*math.cos(angleOctogon))**1)*math.cos(0.5*angleOctogon) - 2*length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon) - length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)
            leftMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) 
             
            rightMotion.rotation_euler.y += angleOctogon
            rightMotion.location.x += length*math.cos(0.5*angleOctogon) + 2*length/((1 + 2*math.cos(angleOctogon))**1)*math.cos(0.5*angleOctogon) + 2*length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon) + length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)
            rightMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) 

            frontMotion.rotation_euler.x += - angleOctogon
            frontMotion.location.y += length*math.cos(0.5*angleOctogon) + 2*length/((1 + 2*math.cos(angleOctogon))**1)*math.cos(0.5*angleOctogon) + 2*length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon) + length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) + length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)
            frontMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) 

            backMotion.rotation_euler.x += angleOctogon
            backMotion.location.y += -length*math.cos(0.5*angleOctogon) - 2*length/((1 + 2*math.cos(angleOctogon))**1)*math.cos(0.5*angleOctogon) - 2*length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon) - length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) - length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)
            backMotion.location.z += -length*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**2)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) -length/((1 + 2*math.cos(angleOctogon))**3)*math.cos(0.5*angleOctogon)*math.cos(angleOctogon) 


            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseOctogonShape-"+str(i)+"_C",
                "BaseOctogonShape-"+str(i)+"_L",
                "BaseOctogonShape-"+str(i)+"_R",
                "BaseOctogonShape-"+str(i)+"_B",
                "BaseOctogonShape-"+str(i)+"_F",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseOctogonShape-"+str(i)+"_C"].name = "BaseOctogonShape-"+str(i) 
   
        if(i>3):
            basePentagonShape = bpy.context.scene.objects['BaseOctogonShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_L"
                if(partI==2):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_R"
                if(partI==3):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseOctogonShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseOctogonShape-"+str(i)+"_B"

            centerMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_C']
            leftMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_L']
            rightMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_R']
            frontMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseOctogonShape-'+str(i)+'_B']  

            centerMotion.scale /= 1 + 2*math.cos(angleOctogon)
            leftMotion.scale /= 1 + 2*math.cos(angleOctogon)
            rightMotion.scale /= 1 + 2*math.cos(angleOctogon)
            frontMotion.scale /= 1 + 2*math.cos(angleOctogon)
            backMotion.scale /= 1 + 2*math.cos(angleOctogon)

            offsetH = (2*length/((1 + 2*math.cos(angleOctogon))**i)*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)
            offsetSideH = 0
            offsetZ = 0
            
            for Q in range(i):
                if(Q==0):
                    offsetSideH += -length*math.cos(0.5*angleOctogon)
                if(Q>0):
                    offsetSideH+= - 2*length/((1 + 2*math.cos(angleOctogon))**Q)*math.cos(0.5*angleOctogon)
            #offsetSideH += -(2*length/((1 + 2*math.cos(angleOctogon))**(i-1))*math.cos(0.5*angleOctogon))*math.cos(angleOctogon)*math.cos(angleOctogon)
            offsetSideH += - 2*length/((1 + 2*math.cos(angleOctogon))**i)*math.cos(0.5*angleOctogon)
            offsetSideH += -(length/((1 + 2*math.cos(angleOctogon))**(i))*math.cos(0.5*angleOctogon))*math.sin(angleOctogon)*math.cos(angleOctogon)        
            
            for K in range(i):
                if(K>0):
                    offsetZ += -2*length/((1 + 2*math.cos(angleOctogon))**(i-K))*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)
                if(K==0):
                    offsetZ += -length/((1 + 2*math.cos(angleOctogon))**(i-K))*math.cos(0.5*angleOctogon)*math.sin(angleOctogon)

            centerMotion.location.z += offsetH

            leftMotion.rotation_euler.y += - angleOctogon
            leftMotion.location.x += offsetSideH
            leftMotion.location.z += offsetZ
             
            rightMotion.rotation_euler.y += angleOctogon
            rightMotion.location.x += -offsetSideH
            rightMotion.location.z += offsetZ 

            frontMotion.rotation_euler.x += - angleOctogon
            frontMotion.location.y += -offsetSideH
            frontMotion.location.z += offsetZ

            backMotion.rotation_euler.x += angleOctogon
            backMotion.location.y += offsetSideH
            backMotion.location.z += offsetZ 


            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseOctogonShape-"+str(i)+"_C",
                "BaseOctogonShape-"+str(i)+"_L",
                "BaseOctogonShape-"+str(i)+"_R",
                "BaseOctogonShape-"+str(i)+"_B",
                "BaseOctogonShape-"+str(i)+"_F",
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()

            bpy.data.objects["BaseOctogonShape-"+str(i)+"_C"].name = "BaseOctogonShape-"+str(i)



#####################################################################################################################################################################
###################################################################### CLEAN FUNCTIONS ########################################################
#####################################################################################################################################################################             
def cleanSquareFractal(n):
    bpy.context.active_object.select_set(False)
    collection = bpy.data.collections['Collection']
    for h in range(n-1):
        collection.objects['BaseSquareShape-'+str(h)].select_set(True)
        bpy.ops.object.delete(use_global=False)
        
def cleanPentagonFractal(n):
    bpy.context.active_object.select_set(False)
    collection = bpy.data.collections['Collection']
    for h in range(n-1):
        collection.objects['BasePentagonShape-'+str(h)].select_set(True)
        bpy.ops.object.delete(use_global=False)
        
def cleanHexagonFractal(n):
    bpy.context.active_object.select_set(False)
    collection = bpy.data.collections['Collection']
    for h in range(n-1):
        collection.objects['BaseHexagonShape-'+str(h)].select_set(True)
        bpy.ops.object.delete(use_global=False)
        
def cleanOctogonFractal(n):
    bpy.context.active_object.select_set(False)
    collection = bpy.data.collections['Collection']
    for h in range(n-1):
        collection.objects['BaseOctogonShape-'+str(h)].select_set(True)
        bpy.ops.object.delete(use_global=False)
